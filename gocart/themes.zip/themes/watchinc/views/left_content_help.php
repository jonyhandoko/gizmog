<div class="leftMenu">
    <h3 class="listTitle">Category</h3>
    <div class="blockNav">
        <h4 class="sub-listTitle"><img src="<?php echo base_url();?>images/arrow.png" class="mright5"><a href="#">Shop</a></h4>
        <ul>
            <li><a href="/privilege">Privilege Member</a></li>
            <li><a href="/order">How to order</a></li>
            <li><a href="/shipping">Shipping Delivery</a></li>
            <li><a href="/return">Shipping Return</a></li>
        </ul>	
    </div>
    <div class="blockNav">
        <h4 class="sub-listTitle"><img src="<?php echo base_url();?>images/arrow.png" class="mright5"><a href="#">Site</a></h4>
        <ul>
            <li><a href="/about">About Us</a></li>
            <li><a href="/terms">Term and Condition</a></li>
            <li><a href="/cart/contactus">Contact Us</a></li>
        </ul>	
    </div>
</div>

<style>
	ul{list-style: none;}
	h4 a{color:black;}
	ul li a{color: black;}
</style>