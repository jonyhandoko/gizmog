		<br class="clear"/>
	</div>
</div>


<div id="footer_lid"></div>
<div class="footer">
	
	<div id="footer_social">
		<!-- AddThis Button BEGIN -->
		<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
		<a class="addthis_button_preferred_1"></a>
		<a class="addthis_button_preferred_2"></a>
		<a class="addthis_button_preferred_3"></a>
		<a class="addthis_button_preferred_4"></a>
		<a class="addthis_button_compact"></a>
		<a class="addthis_counter addthis_bubble_style"></a>
		</div>
		<script type="text/javascript" src="https://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-4e37144a288bd489"></script>
		<!-- AddThis Button END -->
	</div>
	
	<div id="footer_props">
		&copy; <?php echo date('Y')?> Clear Sky Designs &bull; All Rights Reserved
	</div>
	
	<a href="http://clearskydesigns.com" target="_blank" style="position:absolute; right:10px; bottom:10px;"><img src="<?php echo base_url('images/csd_logo.png');?>" alt="Clear Sky Designs"/></a>
</div>

</body>
</html>