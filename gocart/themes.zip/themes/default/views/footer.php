    		</div>
        </div>	
    </div>
    <div class="clear"></div>
    <div class="ads-bottom">
    	<div class="ads-bottom-container">
        	<img src="<?php echo base_url('images/banner');?>/scarlet_ads1.jpg" class="fleft" />
            <img src="<?php echo base_url('images/banner');?>/scarlet_ads2.jpg" class="fright" />
        </div>
    </div>
    <div class="clear"></div>
    <!-- footer -->
    <div class="footer">
        <div class="footerInside">
            <a href="#">About Us | </a>
            <a href="#">Contact Us |</a>
            <a href="#">Policy | </a>
            <a href="#">Shipping and Returns</a><br/>
            <span class="arial11 white" >Copyright 2012 Scarlet. All Right Reserved</span>          
        </div>
        
    </div>
    <!-- footer end -->
</body>
</html>