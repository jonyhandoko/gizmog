<?php include('header.php');?>
<?php echo html_entity_decode($page->content); ?>
<?php include('footer.php');?>