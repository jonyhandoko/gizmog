<div id="left-content">
    <div class="left-nav">
        <ul>
            <li class="category">CLOTHING</li>
            <div class="mbtm20"></div>
            <li class="italic"><a href="#">New Arrival</a></li>
            <li class="italic"><a href="#">Sale</a></li>
            <li class="italic"><a href="#">Dress</a></li>
            <li class="italic"><a href="#">Top</a></li>
            <li class="italic"><a href="#">Skirt</a></li>
        </ul>
        <div class="mbtm40"></div>
         <ul>
            <li style="text-align:left"><a href="#"><img src="<?php echo base_url('images/fb.png');?>" width="150"/></a></li>
            <li style="text-align:left"><a href="#"><img src="<?php echo base_url('images/twit.png');?>" width="70"/></a></li>
        </ul>
    </div>
</div>